import 'package:flutter/material.dart';

import '../models/usuario.dart';
import '../services/api_service.dart';
import './cadastro_page.dart';
import './inicio_page.dart';
import './recuperar_senha_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  final ApiService _api = ApiService();

  bool _carregando = false;
  bool _mostrarSenha = false;

  @override
  void dispose() {
    _emailController.dispose();
    _senhaController.dispose();
    super.dispose();
  }

  void _mensagem(String texto) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(texto)));
  }

  Future<void> _entrar() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;
    setState(() => _carregando = true);
    try {
      final Usuario usuario = await _api.login(
        _emailController.text.trim(),
        _senhaController.text,
      );
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => InicioPage(usuarioId: usuario.id)),
      );
    } catch (e) {
      _mensagem(ApiService.mensagemDeErro(e));
    } finally {
      if (mounted) setState(() => _carregando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const azul = Color(0xFF1E3A5F);
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      width: 82,
                      height: 82,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: azul,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: const Icon(Icons.directions_car_filled_rounded, color: Colors.white, size: 44),
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'IntelligenceCar',
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: azul),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Cuidado inteligente para o seu veículo.',
                      style: TextStyle(fontSize: 15, color: Color(0xFF667085)),
                    ),
                    const SizedBox(height: 34),
                    const Text('Acesse sua conta', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 18),
                    TextFormField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      autocorrect: false,
                      decoration: const InputDecoration(
                        labelText: 'E-mail',
                        prefixIcon: Icon(Icons.email_outlined),
                      ),
                      validator: (value) {
                        final email = value?.trim() ?? '';
                        if (email.isEmpty) return 'Informe seu e-mail.';
                        if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
                          return 'Informe um e-mail válido.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _senhaController,
                      obscureText: !_mostrarSenha,
                      decoration: InputDecoration(
                        labelText: 'Senha',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => _mostrarSenha = !_mostrarSenha),
                          icon: Icon(_mostrarSenha ? Icons.visibility_off : Icons.visibility),
                        ),
                      ),
                      validator: (value) => value == null || value.isEmpty ? 'Informe sua senha.' : null,
                      onFieldSubmitted: (_) => _carregando ? null : _entrar(),
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _carregando ? null : _entrar,
                        child: _carregando
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Text('Entrar'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 50,
                      child: OutlinedButton(
                        onPressed: _carregando
                            ? null
                            : () => Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => const CadastroPage()),
                                ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: azul,
                          side: const BorderSide(color: azul),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: const Text('Criar uma conta'),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextButton(
                      onPressed: _carregando
                          ? null
                          : () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => RecuperarSenhaPage(emailInicial: _emailController.text.trim()),
                                ),
                              ),
                      child: const Text('Esqueci minha senha'),
                    ),
                    const SizedBox(height: 26),
                    const Text(
                      'INTELLIGENCECAR  •  MANUTENÇÃO E HISTÓRICO',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10, letterSpacing: 1.1, color: Color(0xFF98A2B3)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
