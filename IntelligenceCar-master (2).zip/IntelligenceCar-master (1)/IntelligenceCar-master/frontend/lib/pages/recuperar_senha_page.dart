import 'package:flutter/material.dart';

import '../services/api_service.dart';

class RecuperarSenhaPage extends StatefulWidget {
  final String emailInicial;

  const RecuperarSenhaPage({super.key, this.emailInicial = ''});

  @override
  State<RecuperarSenhaPage> createState() => _RecuperarSenhaPageState();
}

class _RecuperarSenhaPageState extends State<RecuperarSenhaPage> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _emailController;
  final _codigoController = TextEditingController();
  final _novaSenhaController = TextEditingController();
  final _confirmarController = TextEditingController();

  final ApiService _api = ApiService();

  bool _carregando = false;
  bool _codigoEnviado = false; // false = passo 1 (e-mail) | true = passo 2 (código + nova senha)
  bool _mostrarSenha = false;

  @override
  void initState() {
    super.initState();
    _emailController = TextEditingController(text: widget.emailInicial);
  }

  @override
  void dispose() {
    _emailController.dispose();
    _codigoController.dispose();
    _novaSenhaController.dispose();
    _confirmarController.dispose();
    super.dispose();
  }

  void _mostrarMensagem(String mensagem) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(mensagem)));
  }

  Future<void> _enviarCodigo() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;

    setState(() => _carregando = true);
    try {
      final mensagem = await _api.solicitarRecuperacaoSenha(_emailController.text);
      if (!mounted) return;
      setState(() => _codigoEnviado = true);
      _mostrarMensagem(mensagem);
    } catch (e) {
      _mostrarMensagem(ApiService.mensagemDeErro(e));
    } finally {
      if (mounted) setState(() => _carregando = false);
    }
  }

  Future<void> _redefinirSenha() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;

    setState(() => _carregando = true);
    try {
      final mensagem = await _api.redefinirSenha(
        email: _emailController.text,
        codigo: _codigoController.text,
        novaSenha: _novaSenhaController.text,
      );
      if (!mounted) return;
      _mostrarMensagem(mensagem);
      Navigator.of(context).pop(); // volta para o login
    } catch (e) {
      _mostrarMensagem(ApiService.mensagemDeErro(e));
    } finally {
      if (mounted) setState(() => _carregando = false);
    }
  }

  InputDecoration _decoracao(String texto) {
    return InputDecoration(
      hintText: texto,
      hintStyle: const TextStyle(
        color: Color(0xFF4D86E8),
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF203F68),
        foregroundColor: Colors.white,
        title: const Text('RECUPERAR SENHA', style: TextStyle(fontSize: 14)),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                const SizedBox(height: 15),
                Text(
                  _codigoEnviado
                      ? 'Digite o código que enviamos para o seu e-mail e escolha uma nova senha.'
                      : 'Informe o e-mail da sua conta. Vamos enviar um código de 6 dígitos.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _emailController,
                  enabled: !_codigoEnviado,
                  keyboardType: TextInputType.emailAddress,
                  autocorrect: false,
                  decoration: _decoracao('E-MAIL'),
                  validator: (valor) {
                    final email = valor?.trim() ?? '';
                    if (email.isEmpty) return 'Informe seu e-mail.';
                    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
                      return 'Informe um e-mail válido.';
                    }
                    return null;
                  },
                ),
                if (_codigoEnviado) ...[
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: _codigoController,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    decoration: _decoracao('CÓDIGO DE 6 DÍGITOS').copyWith(counterText: ''),
                    validator: (valor) {
                      if ((valor ?? '').trim().length != 6) {
                        return 'Digite o código de 6 dígitos.';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: _novaSenhaController,
                    obscureText: !_mostrarSenha,
                    decoration: _decoracao('NOVA SENHA').copyWith(
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => _mostrarSenha = !_mostrarSenha),
                        icon: Icon(
                          _mostrarSenha ? Icons.visibility_off : Icons.visibility,
                        ),
                      ),
                    ),
                    validator: (valor) {
                      final senha = valor ?? '';
                      if (senha.length < 8) {
                        return 'A senha precisa ter pelo menos 8 caracteres.';
                      }
                      if (!RegExp(r'[A-Za-z]').hasMatch(senha) ||
                          !RegExp(r'\d').hasMatch(senha)) {
                        return 'Use letras e números na senha.';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: _confirmarController,
                    obscureText: !_mostrarSenha,
                    decoration: _decoracao('CONFIRMAR NOVA SENHA'),
                    validator: (valor) {
                      if (valor != _novaSenhaController.text) {
                        return 'As senhas não conferem.';
                      }
                      return null;
                    },
                  ),
                ],
                const SizedBox(height: 30),
                SizedBox(
                  width: 230,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: _carregando
                        ? null
                        : (_codigoEnviado ? _redefinirSenha : _enviarCodigo),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF5287CF),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: _carregando
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : Text(
                            _codigoEnviado ? 'REDEFINIR SENHA' : 'ENVIAR CÓDIGO',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
                if (_codigoEnviado)
                  TextButton(
                    onPressed: _carregando
                        ? null
                        : () => setState(() {
                              _codigoEnviado = false;
                              _codigoController.clear();
                              _novaSenhaController.clear();
                              _confirmarController.clear();
                            }),
                    child: const Text('Pedir um novo código'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
