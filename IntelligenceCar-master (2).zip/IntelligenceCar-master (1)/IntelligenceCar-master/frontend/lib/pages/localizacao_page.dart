import 'package:flutter/material.dart';

class LocalizacaoPage extends StatelessWidget {
  const LocalizacaoPage({super.key});

  @override
  Widget build(BuildContext context) {
    const azulEscuro = Color(0xFF1E3A5F);
    const cinzaCard = Color(0xFFEAEAEA);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(
        backgroundColor: azulEscuro,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: const Text('Encontrar Oficinas Próximas', style: TextStyle(color: Colors.white, fontSize: 18)),
        centerTitle: true,
        actions: const [
          Icon(Icons.wifi, color: Colors.white),
          SizedBox(width: 16),
        ],
      ),
      body: Container(
        color: Colors.white,
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFF4F83CC), width: 2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(
                  'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=600',
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      height: 200,
                      color: Colors.grey[300],
                      child: const Icon(Icons.map, size: 50, color: Colors.grey),
                    );
                  },
                ),
              ),
            ),
            Expanded(
              child: Scrollbar(
                thumbVisibility: true,
                thickness: 6,
                radius: const Radius.circular(10),
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: 8,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: cinzaCard,
                        border: Border.all(color: Colors.black, width: 1.5),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Web Motors:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.black)),
                              SizedBox(height: 4),
                              Text('R. Catete ....', style: TextStyle(fontSize: 14, color: Colors.black54)),
                            ],
                          ),
                          Row(
                            children: List.generate(
                              5,
                              (starIndex) => const Icon(Icons.star, color: Colors.amber, size: 18),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}