
import 'package:flutter/material.dart';

import '../services/api_service.dart';
import './login_page.dart';

class CadastroPage extends StatefulWidget {
  const CadastroPage({super.key});

  @override
  State<CadastroPage> createState() => _CadastroPageState();
}

class _CadastroPageState extends State<CadastroPage> {
  final _formKey = GlobalKey<FormState>();

  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _telefoneController = TextEditingController();
  final _senhaController = TextEditingController();

  final ApiService _api = ApiService();

  bool _carregando = false;
  bool _mostrarSenha = false;

  @override
  void dispose() {
    _nomeController.dispose();
    _emailController.dispose();
    _telefoneController.dispose();
    _senhaController.dispose();
    super.dispose();
  }

  void _mostrarMensagem(String mensagem) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(mensagem)),
      );
  }

  Future<void> _cadastrar() async {
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() => _carregando = true);

    try {
      // Envia os dados para POST /api/usuarios.
      // O ApiService já trata a resposta e os erros HTTP.
      await _api.cadastrarUsuario(
        nome: _nomeController.text.trim(),
        email: _emailController.text.trim(),
        telefone: _telefoneController.text.trim(),
        senha: _senhaController.text,
      );

      if (!mounted) return;

      _mostrarMensagem(
        'Cadastro realizado com sucesso! Faça login.',
      );

      // Volta para a tela de login.
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => LoginPage(),
        ),
        (route) => false,
      );
    } catch (e) {
      _mostrarMensagem(
        ApiService.mensagemDeErro(e),
      );
    } finally {
      if (mounted) {
        setState(() => _carregando = false);
      }
    }
  }

  InputDecoration _decoracao(String texto) {
    return InputDecoration(
      hintText: texto,
      hintStyle: const TextStyle(
        color: Color(0xFF4D86E8),
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 16,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF203F68),
        foregroundColor: Colors.white,
        title: const Text(
          'CADASTRO DO USUÁRIO',
          style: TextStyle(fontSize: 14),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                const SizedBox(height: 15),

                TextFormField(
                  controller: _nomeController,
                  textCapitalization: TextCapitalization.words,
                  decoration: _decoracao('NOME'),
                  validator: (valor) {
                    if (valor == null || valor.trim().isEmpty) {
                      return 'Informe seu nome.';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 20),

                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: _decoracao('E-MAIL'),
                  validator: (valor) {
                    final email = valor?.trim() ?? '';

                    if (email.isEmpty) {
                      return 'Informe seu e-mail.';
                    }

                    if (!RegExp(
                      r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                    ).hasMatch(email)) {
                      return 'Informe um e-mail válido.';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 20),

                TextFormField(
                  controller: _telefoneController,
                  keyboardType: TextInputType.phone,
                  decoration: _decoracao('TELEFONE COM DDD'),
                  validator: (valor) {
                    final digitos = (valor ?? '')
                        .replaceAll(RegExp(r'\D'), '');

                    String numero = digitos;

                    if ((numero.length == 12 ||
                            numero.length == 13) &&
                        numero.startsWith('55')) {
                      numero = numero.substring(2);
                    }

                    if (numero.length != 10 &&
                        numero.length != 11) {
                      return 'Informe DDD e telefone válidos.';
                    }

                    if (numero.length == 11 &&
                        numero[2] != '9') {
                      return 'Confira o número do celular.';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 20),

                TextFormField(
                  controller: _senhaController,
                  obscureText: !_mostrarSenha,
                  decoration: _decoracao('SENHA').copyWith(
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          _mostrarSenha = !_mostrarSenha;
                        });
                      },
                      icon: Icon(
                        _mostrarSenha
                            ? Icons.visibility_off
                            : Icons.visibility,
                      ),
                    ),
                  ),
                  validator: (valor) {
                    final senha = valor ?? '';

                    if (senha.isEmpty) {
                      return 'Informe uma senha.';
                    }

                    if (senha.length < 8) {
                      return 'A senha precisa ter pelo menos 8 caracteres.';
                    }

                    if (!RegExp(r'[A-Za-z]').hasMatch(senha) ||
                        !RegExp(r'\d').hasMatch(senha)) {
                      return 'Use letras e números na senha.';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 30),

                SizedBox(
                  width: 230,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: _carregando ? null : _cadastrar,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF5287CF),
                      foregroundColor: Colors.white,
                      side: const BorderSide(
                        color: Colors.black,
                        width: 1.5,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: _carregando
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Text(
                            'CADASTRAR',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
