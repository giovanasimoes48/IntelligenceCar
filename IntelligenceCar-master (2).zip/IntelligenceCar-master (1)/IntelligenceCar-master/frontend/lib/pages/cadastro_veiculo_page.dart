import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import './inicio_page.dart';
import '../services/api_service.dart';

class CadastroVeiculoPage extends StatefulWidget {
  final int usuarioId;

  const CadastroVeiculoPage({
    super.key,
    required this.usuarioId,
  });

  @override
  State<CadastroVeiculoPage> createState() => _CadastroVeiculoPageState();
}

class _CadastroVeiculoPageState extends State<CadastroVeiculoPage> {
  final _formKey = GlobalKey<FormState>();

  final _placaController = TextEditingController();
  final _modeloController = TextEditingController();
  final _marcaController = TextEditingController();
  final _anoController = TextEditingController();
  final _tipoMotorController = TextEditingController();
  final _kmController = TextEditingController();

  bool _carregando = false;
  String get apiUrl => '${ApiService.baseUrl}/veiculos';

  @override
  void dispose() {
    _placaController.dispose();
    _modeloController.dispose();
    _marcaController.dispose();
    _anoController.dispose();
    _tipoMotorController.dispose();
    _kmController.dispose();
    super.dispose();
  }

  void _mostrarMensagem(String mensagem) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(mensagem)));
  }

  Future<void> _cadastrarVeiculo() async {
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) return;

    setState(() => _carregando = true);

    final dados = {
      'usuario_id': widget.usuarioId,
      'placa': _placaController.text.trim().toUpperCase(),
      'modelo': _modeloController.text.trim(),
      'marca': _marcaController.text.trim(),
      'ano': int.parse(_anoController.text.trim()),
      'tipo_motor': _tipoMotorController.text.trim(),
      'quilometragem': int.parse(_kmController.text.trim()),
    };

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode(dados),
      );

      if (!mounted) return;

      if (response.statusCode == 200 || response.statusCode == 201) {
        _mostrarMensagem('Veículo cadastrado com sucesso!');

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => InicioPage(usuarioId: widget.usuarioId),
          ),
        );
      } else {
        String mensagem = 'Não foi possível cadastrar o veículo.';

        try {
          final resposta = jsonDecode(response.body);
          if (resposta is Map<String, dynamic>) {
            mensagem = resposta['error']?.toString() ??
                resposta['message']?.toString() ??
                mensagem;
          }
        } catch (_) {}

        _mostrarMensagem('Erro HTTP ${response.statusCode}: $mensagem');
      }
    } catch (e) {
      if (mounted) _mostrarMensagem('Erro de conexão com o servidor: $e');
    } finally {
      if (mounted) setState(() => _carregando = false);
    }
  }

  InputDecoration _decoracao(String texto) {
    return InputDecoration(
      hintText: texto,
      hintStyle: const TextStyle(
        color: Color(0xFF4D86E8),
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      border: const UnderlineInputBorder(),
    );
  }

  String? _validarTexto(String? valor, String campo) {
    if (valor == null || valor.trim().isEmpty) return 'Preencha $campo';
    return null;
  }

  String? _validarInteiro(String? valor, String campo, {int minimo = 0, int? maximo}) {
    final numero = int.tryParse(valor?.trim() ?? '');

    if (numero == null) return 'Informe um valor numérico para $campo';
    if (numero < minimo) return '$campo inválido';
    if (maximo != null && numero > maximo) return '$campo inválido';

    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E3A5F),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: const Text(
          'CADASTRO DO VEÍCULO',
          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,

      ),
      body: Container(
        color: Colors.white,
        width: double.infinity,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _placaController,
                    textCapitalization: TextCapitalization.characters,
                    decoration: _decoracao('PLACA'),
                    validator: (v) => _validarTexto(v, 'a placa'),
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _modeloController,
                    decoration: _decoracao('MODELO'),
                    validator: (v) => _validarTexto(v, 'o modelo'),
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _marcaController,
                    decoration: _decoracao('MARCA'),
                    validator: (v) => _validarTexto(v, 'a marca'),
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _anoController,
                    keyboardType: TextInputType.number,
                    decoration: _decoracao('ANO'),
                    validator: (v) => _validarInteiro(v, 'ano', minimo: 1900, maximo: DateTime.now().year + 1),
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _tipoMotorController,
                    decoration: _decoracao('TIPO E MOTOR'),
                    validator: (v) => _validarTexto(v, 'o tipo e motor'),
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _kmController,
                    keyboardType: TextInputType.number,
                    decoration: _decoracao('KM ATUAL'),
                    validator: (v) => _validarInteiro(v, 'quilometragem'),
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4F83CC),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                          side: const BorderSide(color: Colors.black),
                        ),
                      ),
                      onPressed: _carregando ? null : _cadastrarVeiculo,
                      child: _carregando
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : const Text(
                              'CADASTRAR',
                              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}