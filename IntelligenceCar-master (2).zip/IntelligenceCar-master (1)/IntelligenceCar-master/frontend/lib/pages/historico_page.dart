import 'package:flutter/material.dart';

import '../models/manutencao.dart';
import '../services/api_service.dart';

class HistoricoPage extends StatefulWidget {
  final int veiculoId;

  const HistoricoPage({super.key, required this.veiculoId});

  @override
  State<HistoricoPage> createState() => _HistoricoPageState();
}

class _HistoricoPageState extends State<HistoricoPage> {
  final ApiService _api = ApiService();
  late Future<List<Manutencao>> _historico;

  @override
  void initState() {
    super.initState();
    _historico = _api.historicoManutencoes(widget.veiculoId);
  }

  Future<void> _atualizar() async {
    setState(() => _historico = _api.historicoManutencoes(widget.veiculoId));
    await _historico;
  }

  String _formatarData(String valor) {
    final data = DateTime.tryParse(valor);
    if (data == null) return valor;
    return '${data.day.toString().padLeft(2, '0')}/${data.month.toString().padLeft(2, '0')}/${data.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(title: const Text('Histórico de manutenções')),
      body: FutureBuilder<List<Manutencao>>(
        future: _historico,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.cloud_off_outlined, size: 42, color: Color(0xFF667085)),
                    const SizedBox(height: 12),
                    const Text('Não foi possível carregar o histórico.', style: TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    Text(
                      ApiService.mensagemDeErro(snapshot.error!),
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Color(0xFF667085)),
                    ),
                    const SizedBox(height: 16),
                    OutlinedButton.icon(
                      onPressed: _atualizar,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Tentar novamente'),
                    ),
                  ],
                ),
              ),
            );
          }

          final itens = snapshot.data ?? [];
          if (itens.isEmpty) {
            return RefreshIndicator(
              onRefresh: _atualizar,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: const [
                  SizedBox(height: 120),
                  Icon(Icons.history, size: 54, color: Color(0xFF98A2B3)),
                  SizedBox(height: 14),
                  Center(child: Text('Nenhuma manutenção registrada ainda.')),
                  SizedBox(height: 8),
                  Center(child: Text('Quando você registrar uma manutenção, ela aparecerá aqui.', textAlign: TextAlign.center)),
                ],
              ),
            );
          }

          return RefreshIndicator(
            onRefresh: _atualizar,
            child: ListView.separated(
              padding: const EdgeInsets.all(18),
              itemCount: itens.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final item = itens[index];
                final preventiva = item.tipo.toLowerCase().contains('prevent');
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: const [
                      BoxShadow(color: Color(0x10000000), blurRadius: 12, offset: Offset(0, 3)),
                    ],
                  ),
                  child: IntrinsicHeight(
                    child: Row(
                      children: [
                        Container(
                          width: 5,
                          decoration: BoxDecoration(
                            color: const Color(0xFF4F83CC),
                            borderRadius: const BorderRadius.horizontal(left: Radius.circular(14)),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        _formatarData(item.data),
                                        style: const TextStyle(color: Color(0xFF667085), fontSize: 12),
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: preventiva ? const Color(0xFFEAF2FF) : const Color(0xFFFFF2E8),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Text(
                                        item.tipo,
                                        style: TextStyle(
                                          color: preventiva ? const Color(0xFF315F9B) : const Color(0xFF9A4D16),
                                          fontSize: 11,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Text(item.descricao, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    const Icon(Icons.speed, size: 15, color: Color(0xFF667085)),
                                    const SizedBox(width: 5),
                                    Text('${item.quilometragem} km', style: const TextStyle(color: Color(0xFF667085), fontSize: 12)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
