# IntelligenceCar — Front-end + Back-end

Aplicativo para cadastro de veículos e organização do histórico de manutenções e documentos.

## Tecnologias

- **Front-end:** Flutter + Dart + Device Preview.
- **Back-end:** Python + Flask + Flask-SQLAlchemy + Flask-CORS.
- **Banco de dados:** MySQL.
- **API:** endpoints REST em `/api`.

## Estrutura

- `frontend/`: aplicativo Flutter, telas, modelos e serviço que consome a API.
- `backend/`: API Flask, controllers, services, models e repositories.
- `backend/database/create_database.sql`: criação do banco, tabelas e procedures.

## 1. Preparar o banco de dados

1. Instale e inicie o MySQL Server.
2. Abra o MySQL Workbench e execute o script `backend/database/create_database.sql`.
3. O script cria o banco `projeto` e as tabelas necessárias. Ele também configura o usuário `usuario` com senha `senha` para ambiente local de desenvolvimento. Se preferir outras credenciais, ajuste o script e a URL no `.env`.

> Use credenciais próprias e não exponha o arquivo `.env` em repositórios públicos.

## 2. Iniciar o back-end

É necessário ter Python 3.10 ou superior instalado.

### Windows (PowerShell)

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Abra `backend/.env` e confirme a URL do banco. Depois execute:

```powershell
python app.py
```

A API ficará disponível em `http://127.0.0.1:5000`. Para conferir, abra esse endereço no navegador; deverá aparecer uma mensagem informando que a API está funcionando.

Se o PowerShell bloquear a ativação do ambiente virtual, você também pode executar diretamente:
```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

## 3. Iniciar o front-end Flutter

Instale o Flutter SDK e confirme a instalação com `flutter doctor`.

Em outro terminal:

```powershell
cd frontend
flutter pub get
flutter run
```

O aplicativo inicia pela tela de login e inclui o Device Preview para testar diferentes tamanhos de tela.

## 4. Endereço da API no front-end

Confira `frontend/lib/services/api_service.dart`:

- **Emulador Android:** `http://10.0.2.2:5000/api`
- **Navegador/desktop na mesma máquina:** `http://127.0.0.1:5000/api`
- **Celular físico:** use o IP local do computador na rede Wi-Fi, por exemplo `http://192.168.0.10:5000/api`, e permita a conexão na firewall.

A API e o banco precisam estar iniciados para as funcionalidades que consultam dados funcionarem.

## Observações

- Este pacote mantém a implementação do projeto enviado e acrescenta instruções de configuração para facilitar a execução.
- O login visual existente deve ser integrado a autenticação real antes de ser usado em produção.
- O sistema depende de MySQL; o script SQL pode precisar de pequenos ajustes conforme a versão e as permissões do seu servidor.
