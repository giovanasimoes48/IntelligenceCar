from datetime import datetime
from extensions import db


class RecuperacaoSenha(db.Model):
    __tablename__ = "recuperacoes_senha"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey("usuarios.id"), nullable=False, index=True)
    codigo_hash = db.Column(db.String(255), nullable=False)
    expira_em = db.Column(db.DateTime, nullable=False)
    tentativas = db.Column(db.Integer, nullable=False, default=0)
    usado = db.Column(db.Boolean, nullable=False, default=False)
    data_criacao = db.Column(db.DateTime, nullable=False, default=datetime.now)

    @classmethod
    def criar(cls, usuario_id, codigo_hash, expira_em):

        cls.query.filter_by(usuario_id=usuario_id, usado=False).update({"usado": True})
        recuperacao = cls(usuario_id=usuario_id, codigo_hash=codigo_hash, expira_em=expira_em)
        db.session.add(recuperacao)
        db.session.commit()
        return recuperacao

    @classmethod
    def buscar_ativa(cls, usuario_id):
        return (
            cls.query.filter_by(usuario_id=usuario_id, usado=False)
            .order_by(cls.id.desc())
            .first()
        )

    def registrar_tentativa_errada(self):
        self.tentativas += 1
        db.session.commit()

    def marcar_como_usada(self):
        self.usado = True
        db.session.commit()
